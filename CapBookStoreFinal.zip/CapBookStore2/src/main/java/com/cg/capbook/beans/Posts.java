package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
@Entity
public class Posts {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int postId;
@ManyToOne
@JoinColumn(name="personEmailId")
Persons persons;
private String postText;
public Posts() {
	super();
	// TODO Auto-generated constructor stub
}
public Posts(int postId, Persons persons, String postText) {
	super();
	this.postId = postId;
	this.persons = persons;
	this.postText = postText;
}
public int getPostId() {
	return postId;
}
public void setPostId(int postId) {
	this.postId = postId;
}
public Persons getPersons() {
	return persons;
}
public void setPersons(Persons persons) {
	this.persons = persons;
}
public String getPostText() {
	return postText;
}
public void setPostText(String postText) {
	this.postText = postText;
}
public Posts(Persons persons, String postText) {
	super();
	this.persons = persons;
	this.postText = postText;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((persons == null) ? 0 : persons.hashCode());
	result = prime * result + postId;
	result = prime * result + ((postText == null) ? 0 : postText.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Posts other = (Posts) obj;
	if (persons == null) {
		if (other.persons != null)
			return false;
	} else if (!persons.equals(other.persons))
		return false;
	if (postId != other.postId)
		return false;
	if (postText == null) {
		if (other.postText != null)
			return false;
	} else if (!postText.equals(other.postText))
		return false;
	return true;
}
@Override
public String toString() {
	return "Posts [postId=" + postId + ", persons=" + persons + ", postText=" + postText + "]";
}


}
