package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.Friend;
import com.cg.capbook.beans.FriendRequest;

public interface FriendDaoServices  extends JpaRepository<Friend,String>{

}
