package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Friend {
	@Id
private String emailId;
private String personFirstName,personLastName;
@ManyToOne
private Persons persons;
public Friend() {
	super();
}
public Friend(String emailId, String personFirstName, String personLastName, Persons persons) {
	super();
	this.emailId = emailId;
	this.personFirstName = personFirstName;
	this.personLastName = personLastName;
	this.persons = persons;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getPersonFirstName() {
	return personFirstName;
}
public void setPersonFirstName(String personFirstName) {
	this.personFirstName = personFirstName;
}
public String getPersonLastName() {
	return personLastName;
}
public void setPersonLastName(String personLastName) {
	this.personLastName = personLastName;
}
public Persons getPersons() {
	return persons;
}
public void setPersons(Persons persons) {
	this.persons = persons;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
	result = prime * result + ((personFirstName == null) ? 0 : personFirstName.hashCode());
	result = prime * result + ((personLastName == null) ? 0 : personLastName.hashCode());
	result = prime * result + ((persons == null) ? 0 : persons.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Friend other = (Friend) obj;
	if (emailId == null) {
		if (other.emailId != null)
			return false;
	} else if (!emailId.equals(other.emailId))
		return false;
	if (personFirstName == null) {
		if (other.personFirstName != null)
			return false;
	} else if (!personFirstName.equals(other.personFirstName))
		return false;
	if (personLastName == null) {
		if (other.personLastName != null)
			return false;
	} else if (!personLastName.equals(other.personLastName))
		return false;
	if (persons == null) {
		if (other.persons != null)
			return false;
	} else if (!persons.equals(other.persons))
		return false;
	return true;
}
@Override
public String toString() {
	return "Friend [emailId=" + emailId + ", personFirstName=" + personFirstName + ", personLastName=" + personLastName
			+ ", persons=" + persons + "]";
}

}
