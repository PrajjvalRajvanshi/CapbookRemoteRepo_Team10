package com.cg.capbook.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.exceptions.PersonAccountNotFoundException;

@ControllerAdvice
public class CapBookException {
	    @ExceptionHandler(PersonAccountNotFoundException.class)
	    public ModelAndView handelMovieNotFoundException(PersonAccountNotFoundException e)
	    {
	    	return new ModelAndView("index","errorMessage",e.getMessage());
	    }
}
