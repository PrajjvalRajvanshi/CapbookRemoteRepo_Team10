package com.cg.capbook.services;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.daoservices.CapBookDAOServices;
import com.cg.capbook.daoservices.ProfilePictureDAO;
import com.cg.capbook.daoservices.ProfilePictureDAOSrevices;
import com.cg.capbook.exceptions.FileStorageException;
import com.cg.capbook.exceptions.MyFileNotFoundException;

@Component("capBookServices")
public class CapBookServicesImpl implements CapBookServices{
	@Autowired
	CapBookDAOServices capBookDAOServices;
	ProfilePictureDAO profilePicture = new ProfilePictureDAOSrevices();
	@Override
	public String acceptPersonDetails(Persons persons) {
		persons = capBookDAOServices.save(persons);
		return persons.getPersonEmailId();
	}
	@Override
	public Persons getPersonDetails(String personEmailId) throws Exception {
		Persons persons=capBookDAOServices.findById(personEmailId).orElseThrow(()-> new Exception());
		return persons;
	}
	@Override
	public void inserRecords(MultipartFile photo) throws IOException {
	profilePicture.inserRecords(photo);
	}
	
}
