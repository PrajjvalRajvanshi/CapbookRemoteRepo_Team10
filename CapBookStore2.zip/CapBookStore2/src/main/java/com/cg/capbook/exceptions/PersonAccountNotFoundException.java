package com.cg.capbook.exceptions;
@SuppressWarnings("serial")
public class PersonAccountNotFoundException extends Exception {
	public PersonAccountNotFoundException() {
		super();
	}
	public PersonAccountNotFoundException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public PersonAccountNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
	public PersonAccountNotFoundException(String message) {
		super(message);
	}
	public PersonAccountNotFoundException(Throwable cause) {
		super(cause);
	}
}