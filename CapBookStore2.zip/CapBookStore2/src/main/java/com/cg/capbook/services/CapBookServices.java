package com.cg.capbook.services;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.exceptions.FileStorageException;

public interface CapBookServices {
public String acceptPersonDetails(Persons persons);
public Persons getPersonDetails(String emailId) throws Exception;
public void inserRecords(MultipartFile photo) throws IOException;

}
