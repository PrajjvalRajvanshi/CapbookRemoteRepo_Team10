package com.cg.capbook.services;

public class FriendRequestServices  {

}
