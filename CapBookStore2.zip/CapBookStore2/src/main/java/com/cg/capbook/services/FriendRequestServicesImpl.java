package com.cg.capbook.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Friend;
import com.cg.capbook.beans.FriendRequest;
import com.cg.capbook.beans.Persons;
import com.cg.capbook.daoservices.FriendDaoServices;
import com.cg.capbook.daoservices.FriendRequestDaoServices;
import com.cg.capbook.exceptions.FriendRequestAlreadySentException;
import com.cg.capbook.exceptions.PersonAccountNotFoundException;
@Component("friendRequestServices")
public class FriendRequestServicesImpl implements  FriendRequestServices{
	@Autowired
	private FriendDaoServices friendDaoServices;
	@Autowired
	private FriendRequestDaoServices friendRequestDaoServices;
	@Autowired
	private CapBookServices capBookServices;

	@Override
	public boolean sendFriendRequest(String senderEmailId, String receiverEmailId)
			throws PersonAccountNotFoundException, FriendRequestAlreadySentException {
		if(friendRequestDaoServices.findFriendRequest(senderEmailId, receiverEmailId)!=null)
			throw new FriendRequestAlreadySentException("friend request sent already");
		FriendRequest friendRequest =new FriendRequest();
		friendRequest.setSenderEmailId(senderEmailId);
		friendRequest.setReceiverEmailId(receiverEmailId);
		friendRequestDaoServices.save(friendRequest);
		return true;
	}

	@Override
	public boolean confirmFriendRequest(String senderEmailId, String receiverEmailId) throws Exception {
		Persons senderPerson=capBookServices.getPersonDetails(senderEmailId);
		Persons receiverPerson=capBookServices.getPersonDetails(receiverEmailId);
		
		Friend senderFriend=new Friend();
		Friend receiverFriend=new Friend();
		
		senderFriend.setEmailId(senderEmailId);
		senderFriend.setPersonFirstName(senderPerson.getPersonFirstName());
		senderFriend.setPersonLastName(senderPerson.getPersonLastName());
		friendDaoServices.save(senderFriend);
		
		receiverFriend.setEmailId(receiverEmailId);
		receiverFriend.setPersonFirstName(receiverPerson.getPersonFirstName());
		receiverFriend.setPersonLastName(receiverPerson.getPersonLastName());
		friendDaoServices.save(receiverFriend);
		  friendRequestDaoServices.deleteFriendRequest(senderEmailId, receiverEmailId);
		 
		return true;
	}

	@Override
	public boolean declineFriendRequest(String senderEmailId, String receiverEmailId) {
		  friendRequestDaoServices.deleteFriendRequest(senderEmailId, receiverEmailId);
		 
		return true;
	}

	@Override
	public List<FriendRequest> showAllFriendRequest(String receiverEmailId) {
		List<FriendRequest> allPendingFriendRequest=friendRequestDaoServices.findAllPendingFriendRequest(receiverEmailId);
		return allPendingFriendRequest;
	}

}
