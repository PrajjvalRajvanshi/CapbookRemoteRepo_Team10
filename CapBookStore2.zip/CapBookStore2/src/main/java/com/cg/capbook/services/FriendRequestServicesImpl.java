package com.cg.capbook.services;

public class FriendRequestServicesImpl {

}
