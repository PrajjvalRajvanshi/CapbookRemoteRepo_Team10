package com.cg.capbook.controllers;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.exceptions.BillDetailsNotFoundException;
import com.cg.capbook.exceptions.BillingServicesDownException;
import com.cg.capbook.exceptions.CustomerDetailsNotFoundException;
import com.cg.capbook.exceptions.InvalidBillMonthException;
import com.cg.capbook.exceptions.PlanDetailsNotFoundException;
import com.cg.capbook.exceptions.PostpaidAccountNotFoundException;
import com.cg.capbook.services.CapBookServices;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
@Controller
public class CapBookController {
	@Autowired
	private CapBookServices capBookServices;
	Persons persons;
	@RequestMapping("/registrationDa")
	public ModelAndView registerPersonAction(@ModelAttribute Persons persons) throws MessagingException  {
		String personId=capBookServices.acceptPersonDetails(persons);
		return new ModelAndView("index","persons",persons);
	}
	@RequestMapping("/personLogin")
	public ModelAndView completeRegistrationUsingGeneratedCode(@RequestParam("personEmailId") String personEmailId,@RequestParam("personPassword") String personPassword) throws Exception  {
		Persons persons = capBookServices.getPersonDetails(personEmailId);
		if(persons.getPersonPassword().equals(personPassword))
		return new ModelAndView("profilePage","persons",persons);
		
		else
			return new ModelAndView("registrationSuccess","persons",persons);
	}
	
}