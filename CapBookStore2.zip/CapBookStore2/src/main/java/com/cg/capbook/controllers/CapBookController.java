package com.cg.capbook.controllers;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.exceptions.FileStorageException;
import com.cg.capbook.exceptions.MyFileNotFoundException;
import com.cg.capbook.exceptions.CustomerDetailsNotFoundException;
import com.cg.capbook.exceptions.InvalidBillMonthException;
import com.cg.capbook.exceptions.PlanDetailsNotFoundException;
import com.cg.capbook.exceptions.PostpaidAccountNotFoundException;
import com.cg.capbook.services.CapBookServices;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
@SessionAttributes("personEmailId")
@Controller
public class CapBookController {
	@Autowired
	private CapBookServices capBookServices;
	Persons persons;
	@RequestMapping("/registrationDa")
	public ModelAndView registerPersonAction(
			@Valid @ModelAttribute Persons persons,BindingResult bindingResultPersons ) throws MessagingException  {
		  if(bindingResultPersons.hasErrors()) return new ModelAndView("registerationPage");
		 
		String personId=capBookServices.acceptPersonDetails(persons);
		return new ModelAndView("index","persons",persons);
	}
	
	@RequestMapping(value = "/logout")
	public String logoutFromApp(HttpSession session) {
		session.invalidate();
		return "index";
	}
	
	@RequestMapping(value = "/InsertImage", method = RequestMethod.POST)
	public ModelAndView save(@RequestParam("photo") MultipartFile photo) {

		try {
			capBookServices.inserRecords(photo);

			return new ModelAndView("index", "msg", "Records succesfully inserted into database.");

		} catch (Exception e) {
			return new ModelAndView("index", "msg", "Error: " + e.getMessage());
		}
	}
	
}