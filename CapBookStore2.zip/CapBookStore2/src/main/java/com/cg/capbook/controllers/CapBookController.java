package com.cg.capbook.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.services.CapBookServices;

@SessionAttributes("personEmailId")
@Controller
public class CapBookController {
	@Autowired
	private CapBookServices capBookServices;
	  private static String UPLOADED_FOLDER = "D:\\JavaFullStackFinalProject\\CapBookStore2\\src\\main\\resources\\static\\images"; 
	 Persons persons;
	@RequestMapping("/registrationDa")
	public ModelAndView registerPersonAction(
			@Valid @ModelAttribute Persons persons,BindingResult bindingResultPersons )  {
		  if(bindingResultPersons.hasErrors()) return new ModelAndView("registerationPage");
		capBookServices.acceptPersonDetails(persons);
		return new ModelAndView("index","persons",persons);
	}
	
	@RequestMapping(value = "/logout")
	public String logoutFromApp(HttpSession session) {
		session.invalidate();
		return "index";
	}
	

	@RequestMapping("/passwordReset")
	public ModelAndView passwordResetGeneratedCode(@RequestParam("personEmailId") String personEmailId,@RequestParam("securityAnswer") String securityAnswer) throws Exception  {
		Persons persons = capBookServices.getPersonDetails(personEmailId);
		if(capBookServices.checkPassword(securityAnswer, persons.getSecurityAnswer())==true)
		return new ModelAndView("newPassword","persons",persons);
		
		else
			return new ModelAndView("registrationSuccess","persons",persons);
	}
	
	@RequestMapping("/setPassword")
	public ModelAndView passwordSetGeneratedCode(@RequestParam("personEmailId") String personEmailId,@RequestParam("personPassword") String personPassword,@RequestParam("repeatPersonPassword") String repeatPersonPassword) throws Exception  {
		Persons persons=capBookServices.getPersonDetails(personEmailId);
		if(repeatPersonPassword.equals(personPassword)) {
			persons.setPersonPassword(personPassword);
			persons.setRepeatPersonPassword(repeatPersonPassword);
		persons=capBookServices.setPassword(persons);
		return new ModelAndView("index","persons",persons);
		}
		else
			return new ModelAndView("newPassword","persons",persons);
	}
	
	/*
	 * @RequestMapping(value= {"/uploadProfilePicture"}) public String
	 * uploadProfilePicturePage(Model model) { File file = new File(uploadingDir);
	 * model.addAttribute("files", file.listFiles()); return "uploadProfilePicture";
	 * }
	 * 
	 * 
	 * @RequestMapping(value="/uploadProfilePic",method = RequestMethod.POST) public
	 * ModelAndView uploadProfilePic( @RequestParam("uploadingFiles")
	 * MultipartFile[] uploadingFiles,@RequestParam("personEmailId")String
	 * personEmailId) throws Exception { Persons persons =
	 * capBookServices.getPersonDetails(personEmailId); for(MultipartFile
	 * uploadedFile : uploadingFiles) { File file = new
	 * File("\\images\\"+uploadedFile.getOriginalFilename()); String file1
	 * =file.getAbsolutePath().toString();
	 * 
	 * persons.setPhoto(file1);
	 * 
	 * capBookServices.setPassword(persons); uploadedFile.transferTo(file);
	 * 
	 * }
	 * 
	 * return new ModelAndView("profilePage","persons",persons);
	 * 
	 * }
	 */
	  @PostMapping("/upload") // //new annotation since 4.3
	    public ModelAndView singleFileUpload(@RequestParam("file") MultipartFile file,String personEmailId) throws Exception {
		  Persons persons = capBookServices.getPersonDetails(personEmailId);
	        if (file.isEmpty()) {
	        	String message="Please select a file to upload";
	            return new ModelAndView("profilePage","message",message);
	        }

	        try {
	            byte[] bytes = file.getBytes();
	            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
	            Files.write(path, bytes);
	            file.transferTo(new File("D:\\JavaFullStackFinalProject\\CapBookStore2\\src\\main\\resources\\static\\images"+ file.getOriginalFilename()));
	            File file1 = new File( file.getOriginalFilename());
	            persons.setPhoto(file1.getPath().toString());
	        } catch (IOException e) {
	            e.printStackTrace();}
	        capBookServices.setPassword(persons);
			return new ModelAndView("profilePage","persons",persons);
			
	  }
}