package com.cg.capbook.exceptions;
@SuppressWarnings("serial")
public class PersonDetailsNotFoundException extends Exception {
	public PersonDetailsNotFoundException() {
		super();
	}
	public PersonDetailsNotFoundException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public PersonDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
	public PersonDetailsNotFoundException(String message) {
		super(message);
	}
	public PersonDetailsNotFoundException(Throwable cause) {
		super(cause);
	}
}