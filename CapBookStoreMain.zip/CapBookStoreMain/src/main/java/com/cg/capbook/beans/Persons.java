package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Persons {
	private String personFirstName;
	private String personLastName;
	@Id
	private String personEmailId;
	private String personPassword;
	private String repeatPersonPassword;
	private String dateOfBirthOfPerson;
	private long verificationCodeForMail;
	public String getPersonFirstName() {
		return personFirstName;
	}
	public void setPersonFirstName(String personFirstName) {
		this.personFirstName = personFirstName;
	}
	public String getPersonLastName() {
		return personLastName;
	}
	public void setPersonLastName(String personLastName) {
		this.personLastName = personLastName;
	}
	public String getPersonEmailId() {
		return personEmailId;
	}
	public void setPersonEmailId(String personEmailId) {
		this.personEmailId = personEmailId;
	}
	public String getPersonPassword() {
		return personPassword;
	}
	public void setPersonPassword(String personPassword) {
		this.personPassword = personPassword;
	}
	public String getRepeatPersonPassword() {
		return repeatPersonPassword;
	}
	public void setRepeatPersonPassword(String repeatPersonPassword) {
		this.repeatPersonPassword = repeatPersonPassword;
	}
	public String getDateOfBirthOfPerson() {
		return dateOfBirthOfPerson;
	}
	public void setDateOfBirthOfPerson(String dateOfBirthOfPerson) {
		this.dateOfBirthOfPerson = dateOfBirthOfPerson;
	}
	public long getVerificationCodeForMail() {
		return verificationCodeForMail;
	}
	public void setVerificationCodeForMail(long verificationCodeForMail) {
		this.verificationCodeForMail = verificationCodeForMail;
	}
	public Persons(String personFirstName, String personLastName, String personEmailId, String personPassword,
			String repeatPersonPassword, String dateOfBirthOfPerson, long verificationCodeForMail) {
		super();
		this.personFirstName = personFirstName;
		this.personLastName = personLastName;
		this.personEmailId = personEmailId;
		this.personPassword = personPassword;
		this.repeatPersonPassword = repeatPersonPassword;
		this.dateOfBirthOfPerson = dateOfBirthOfPerson;
		this.verificationCodeForMail = verificationCodeForMail;
	}
	public Persons(String personFirstName, String personLastName, String personPassword, String repeatPersonPassword,
			String dateOfBirthOfPerson, long verificationCodeForMail) {
		super();
		this.personFirstName = personFirstName;
		this.personLastName = personLastName;
		this.personPassword = personPassword;
		this.repeatPersonPassword = repeatPersonPassword;
		this.dateOfBirthOfPerson = dateOfBirthOfPerson;
		this.verificationCodeForMail = verificationCodeForMail;
	}
	public Persons() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Persons [personFirstName=" + personFirstName + ", personLastName=" + personLastName + ", personEmailId="
				+ personEmailId + ", personPassword=" + personPassword + ", repeatPersonPassword="
				+ repeatPersonPassword + ", dateOfBirthOfPerson=" + dateOfBirthOfPerson  + "]";
	}
	
	
}
