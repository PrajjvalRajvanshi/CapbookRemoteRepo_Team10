package com.cg.capbook.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.exceptions.EmailIdAlreadyExistsException;
import com.cg.capbook.exceptions.PersonDetailsNotFoundException;

@ControllerAdvice
public class CapBookException {
	    @ExceptionHandler(PersonDetailsNotFoundException.class)
	    public ModelAndView handelMovieNotFoundException(PersonDetailsNotFoundException e)
	    {
	    	return new ModelAndView("index","errorMessage",e.getMessage());
	    }
	    @ExceptionHandler(EmailIdAlreadyExistsException.class)
	    public ModelAndView handelEmailIdAlreadyExistsException(EmailIdAlreadyExistsException e)
	    {
	    	return new ModelAndView("index","errorMessage",e.getMessage());
	    }
}
