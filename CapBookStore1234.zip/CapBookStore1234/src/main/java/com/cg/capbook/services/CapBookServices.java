package com.cg.capbook.services;

import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.beans.Posts;
import com.cg.capbook.beans.Profile;
import com.cg.capbook.exceptions.EmailIdAlreadyExistsException;
import com.cg.capbook.exceptions.PersonDetailsNotFoundException;

public interface CapBookServices {
public String acceptPersonDetails(Persons persons) throws EmailIdAlreadyExistsException, PersonDetailsNotFoundException;
public Persons getPersonDetails(String emailId) throws Exception;
public boolean checkPassword(String plainPassword,String hashedPassword);
public Persons setPassword(Persons persons);
public Persons saveImage(MultipartFile photo,String personEmailId) throws Exception;
public Persons updateProfile(String bioInformation,String profession, String relationshipStatus,String location,String personEmailId) throws PersonDetailsNotFoundException;
}
