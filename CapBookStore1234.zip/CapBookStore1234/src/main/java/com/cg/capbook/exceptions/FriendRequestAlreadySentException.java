package com.cg.capbook.exceptions;

public class FriendRequestAlreadySentException extends Exception {

	public FriendRequestAlreadySentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FriendRequestAlreadySentException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FriendRequestAlreadySentException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FriendRequestAlreadySentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FriendRequestAlreadySentException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
