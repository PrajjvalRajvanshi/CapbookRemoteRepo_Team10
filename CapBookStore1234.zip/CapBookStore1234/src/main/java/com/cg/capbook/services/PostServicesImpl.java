package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.capbook.beans.Persons;
import com.cg.capbook.beans.Posts;
import com.cg.capbook.daoservices.CapBookDAOServices;
import com.cg.capbook.daoservices.PostDAOServices;
import com.cg.capbook.exceptions.PersonDetailsNotFoundException;
@Component("postServices")
public class PostServicesImpl implements PostServices{
	@Autowired
	CapBookDAOServices capBookDAOServices;
	@Autowired
	PostDAOServices postDAOServices;
	@Override
	public Persons createPost(String emailId, String postText) throws PersonDetailsNotFoundException {
		Persons person = capBookDAOServices.findById(emailId).orElseThrow(()->new PersonDetailsNotFoundException("Person is not found"));
		Posts post =new Posts(person,postText);
		postDAOServices.save(post);
		return person;
	}

	

}
