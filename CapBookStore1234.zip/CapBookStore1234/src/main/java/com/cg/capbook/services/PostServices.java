package com.cg.capbook.services;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.beans.Posts;
import com.cg.capbook.exceptions.PersonDetailsNotFoundException;

public interface PostServices {
	Persons createPost(String emailId,String postText) throws PersonDetailsNotFoundException;
}
