package com.cg.capbook.exceptions;
@SuppressWarnings("serial")
public class EmailIdAlreadyExistsException extends Exception {
	public EmailIdAlreadyExistsException() {
		super();
	}
	public EmailIdAlreadyExistsException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public EmailIdAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
	}
	public EmailIdAlreadyExistsException(String message) {
		super(message);
	}
	public EmailIdAlreadyExistsException(Throwable cause) {
		super(cause);
	}
}