package com.project.stepdefinition;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.project.pagebeans.RegistrationPageBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationPageStepDefinition {
	private WebDriver driver ;
	private RegistrationPageBean pageBean ;
	WebElement element;
	
@Before
public void setUpTestEnv() {
	System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
	driver=new ChromeDriver();	
	
}
	
@Given("^User is trying to Register on Capbook on the browser$")
public void user_is_trying_to_Register_on_Capbook_on_the_browser() throws Throwable {
	driver.get("D:\\JavaFullStackFinalProject\\CapBookStore2\\src\\main\\webapp\\views\\registerationPage.jsp");
    pageBean = PageFactory.initElements(driver, RegistrationPageBean.class);
}

// person first name
@When("^User signup without entering 'personFirstName'$")
public void user_signup_without_entering_personFirstName() throws Throwable {
//	WebDriverWait wait = new WebDriverWait(driver, 100);
//	element= wait.until(ExpectedConditions.elementToBeClickable(By.id("usrUtils")));
	 driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	pageBean.clickSignUp();
   
}

@Then("^'User First Name Should Not Be Empty' alert message should be displayed$")
public void user_First_Name_Should_Not_Be_Empty_alert_message_should_be_displayed() throws Throwable {
	String expectedAlertMessage = "User First Name Should Not Be Empty";
    String actualAlertMessage = driver.switchTo().alert().getText();
    Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
}

// person last name
@When("^User signup without entering 'personLastName'$")
public void user_signup_without_entering_personLastName() throws Throwable {
    driver.switchTo().alert().dismiss();
    pageBean.setPersonFirstName("Satish");
    pageBean.clickSignUp();  
}

@Then("^'User Last Name Should Not Be Empty' alert message should be displayed$")
public void user_Last_Name_Should_Not_Be_Empty_alert_message_should_be_displayed() throws Throwable {
	String expectedAlertMessage = "User Last Name Should Not Be Empty";
    String actualAlertMessage = driver.switchTo().alert().getText();
    Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
}

@When("^User signup without entering 'dateOfBirthOfPerson'$")
public void user_signup_without_entering_dateOfBirthOfPerson() throws Throwable {
	driver.switchTo().alert().dismiss();
    pageBean.setPersonLastName("Mahajan");
    pageBean.clickSignUp();  
}

@Then("^'Date of Birth Should Not Be Empty' alert message should be displayed$")
public void date_of_Birth_Should_Not_Be_Empty_alert_message_should_be_displayed() throws Throwable {
    String expectedAlertMessage = "Date of Birth Should Not Be Empty";
    String actualAlertMessage = driver.switchTo().alert().getText();
    Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
}

@When("^User signup without entering 'personEmailId'$")
public void user_signup_without_entering_personEmailId() throws Throwable {
	driver.switchTo().alert().dismiss();
    pageBean.setDateOfBirthOfPerson("12/01/1994");
    pageBean.clickSignUp();  
}

@Then("^'Email Id Should Not Be Empty or Invalid' alert message should be displayed$")
public void email_Id_Should_Not_Be_Empty_or_Invalid_alert_message_should_be_displayed() throws Throwable {
	String expectedAlertMessage = "Email Id Should Not Be Empty or Invalid";
    String actualAlertMessage = driver.switchTo().alert().getText();
    Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
   }

@When("^User signup without entering 'securityAnswer'$")
public void user_signup_without_entering_securityAnswer() throws Throwable {
	driver.switchTo().alert().dismiss();
    pageBean.setPersonEmailId("satish.mahajan@gmail.com");
    pageBean.clickSignUp();  
}

@Then("^'Security Answer is required for password recovery' alert message should be displayed$")
public void security_Answer_is_required_for_password_recovery_alert_message_should_be_displayed() throws Throwable {
	String expectedAlertMessage = "Security Answer is required for password recovery";
    String actualAlertMessage = driver.switchTo().alert().getText();
    Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
}

@When("^User signup without entering 'personPassword'$")
public void user_signup_without_entering_personPassword() throws Throwable {
	driver.switchTo().alert().dismiss();
    pageBean.setSecurityAnswer("bunny");
    pageBean.clickSignUp(); 
}

@Then("^'Password Should Not Be Empty and Should contain at least One Capital letter, One special character and One Number' alert message should be displayed$")
public void password_Should_Not_Be_Empty_and_Should_contain_at_least_One_Capital_letter_One_special_character_and_One_Number_alert_message_should_be_displayed() throws Throwable {
	String expectedAlertMessage = "Password Should Not Be Empty and Should contain at least One Capital letter, One special character and One Number";
    String actualAlertMessage = driver.switchTo().alert().getText();
    Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
}

@When("^User signup without entering 'repeatPersonPassword'$")
public void user_signup_without_entering_repeatPersonPassword() throws Throwable {
	driver.switchTo().alert().dismiss();
    pageBean.setPersonPassword("mypassword001!");
    pageBean.clickSignUp(); 
}

@Then("^'Confirm Password Should Not Be Empty' alert message should be displayed$")
public void confirm_Password_Should_Not_Be_Empty_alert_message_should_be_displayed() throws Throwable {
	String expectedAlertMessage = "Confirm Password Should Not Be Empty";
    String actualAlertMessage = driver.switchTo().alert().getText();
    Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
}

// all the correct details 
@When("^User is trying to sign up with all the correct information$")
public void user_is_trying_to_sign_up_with_all_the_correct_information() throws Throwable {
	driver.switchTo().alert().dismiss();
	pageBean.setPersonFirstName("Satish");
    pageBean.setPersonLastName("Mahajan");
    pageBean.setDateOfBirthOfPerson("12/01/1994");
    pageBean.setPersonEmailId("asas01!");
    pageBean.setSecurityAnswer("bunny");
    pageBean.setPersonPassword("mypassword001!");
    pageBean.setRepeatPersonPassword("mypassword001!");
    pageBean.clickSignUp(); 
}

@Then("^'Successfully Registered On Capbook' alert message should be displayed$")
public void successfully_Registered_On_Capbook_alert_message_should_be_displayed() throws Throwable {
	String expectedAlertMessage = "Successfully Registered On Capbook";
    String actualAlertMessage = driver.switchTo().alert().getText();
    Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
}

@After
public void tearDownTestEnv() {
	driver.close();
}
}
