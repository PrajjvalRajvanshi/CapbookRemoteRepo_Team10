package com.project.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPageBean {

	@FindBy(how = How.NAME,name="personFirstName")
	private WebElement personFirstName;
	
	@FindBy(how = How.NAME,name="personLastName")
	private WebElement personLastName;
	
	@FindBy(how = How.NAME,name="dateOfBirthOfPerson")
	private WebElement dateOfBirthOfPerson;
	
	@FindBy(how = How.NAME,name="personEmailId")
	private WebElement personEmailId;
	
	@FindBy(how = How.NAME,name="securityAnswer")
	private WebElement securityAnswer;
	
	@FindBy(how = How.NAME,name="personPassword")
	private WebElement personPassword;
	
	@FindBy(how = How.NAME,name="repeatPersonPassword")
	private WebElement repeatPersonPassword;

	@FindBy(how = How.NAME,name="signupbtn")
	private WebElement signupbtn;
	
	
	public void clickSignUp() {
		signupbtn.submit();
	}
//	public WebElement getSignupbtn() {
//		return signupbtn;
//	}
	
	public RegistrationPageBean() {}

	public RegistrationPageBean(WebElement personFirstName, WebElement personLastName, WebElement dateOfBirthOfPerson,
			WebElement personEmailId, WebElement securityAnswer, WebElement personPassword,
			WebElement repeatPersonPassword) {
		super();
		this.personFirstName = personFirstName;
		this.personLastName = personLastName;
		this.dateOfBirthOfPerson = dateOfBirthOfPerson;
		this.personEmailId = personEmailId;
		this.securityAnswer = securityAnswer;
		this.personPassword = personPassword;
		this.repeatPersonPassword = repeatPersonPassword;
	}

	public String getPersonFirstName() {
		return personFirstName.getAttribute("value");
	}

	public void setPersonFirstName(String personFirstName) {
		this.personFirstName.sendKeys(personFirstName);
	}

	public String getPersonLastName() {
		return personLastName.getAttribute("value");
	}

	public void setPersonLastName(String personLastName) {
		this.personLastName.sendKeys(personLastName);
	}

	public String getDateOfBirthOfPerson() {
		return dateOfBirthOfPerson.getAttribute("value");
	}

	public void setDateOfBirthOfPerson(String dateOfBirthOfPerson) {
		this.dateOfBirthOfPerson.sendKeys(dateOfBirthOfPerson);
	}

	public String getPersonEmailId() {
		return personEmailId.getAttribute("value");
	}

	public void setPersonEmailId(String personEmailId) {
		this.personEmailId.sendKeys(personEmailId);
	}

	public String getSecurityAnswer() {
		return securityAnswer.getAttribute("value");
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer.sendKeys(securityAnswer);
	}

	public String getPersonPassword() {
		return personPassword.getAttribute("value");
	}

	public void setPersonPassword(String personPassword) {
		this.personPassword.sendKeys(personPassword);
	}

	public String getRepeatPersonPassword() {
		return repeatPersonPassword.getAttribute("value");
	}

	public void setRepeatPersonPassword(String repeatPersonPassword) {
		this.repeatPersonPassword.sendKeys(repeatPersonPassword);
	}

}
