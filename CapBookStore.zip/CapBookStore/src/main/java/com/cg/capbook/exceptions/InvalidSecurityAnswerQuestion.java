package com.cg.capbook.exceptions;
//abcd
public class InvalidSecurityAnswerQuestion extends Exception{

}
