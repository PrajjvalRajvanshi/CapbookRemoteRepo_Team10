package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Person;
import com.cg.capbook.daoservices.CapBookDAOServices;
@Component("capBookServices")
public class CapBookServicesImpl implements CapBookServices{
	@Autowired
	CapBookDAOServices capBookDAOServices;
	@Override
	public String acceptPersonDetails(Person person) {
		//person.setVerificationCode((long) ((Math.random()*999999)-1));
		person = capBookDAOServices.save(person);
		return person.getEmailId();
	}
	@Override
	public Person getPersonDetails(String emailId) throws Exception {
		Person person=capBookDAOServices.findById(emailId).orElseThrow(()-> new Exception());
		return person;
	}

}
