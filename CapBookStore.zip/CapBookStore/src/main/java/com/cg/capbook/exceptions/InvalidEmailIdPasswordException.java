package com.cg.capbook.exceptions;
//abcd
public class InvalidEmailIdPasswordException extends Exception{

}
