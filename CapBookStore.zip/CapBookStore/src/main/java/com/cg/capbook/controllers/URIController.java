package com.cg.capbook.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capbook.beans.Person;

@Controller
public class URIController {
	Person person;
	@RequestMapping(value= {"/","/indexPage"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@ModelAttribute
	public Person getPerson() {
		person=new Person();
		return person;
	}
	
}