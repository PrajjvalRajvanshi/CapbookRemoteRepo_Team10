package com.cg.capbook.services;

import com.cg.capbook.beans.Person;

public interface CapBookServices {
public String acceptPersonDetails(Person person);
public Person getPersonDetails(String emailId) throws Exception;
}
