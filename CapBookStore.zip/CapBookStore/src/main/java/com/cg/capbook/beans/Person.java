package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Person {
	private String firstName;
	private String lastName;
	@Id
	private String emailId;
	private String password;
	private String repeatPassword;
	private String date;
	private long verificationCode;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRepeatPassword() {
		return repeatPassword;
	}
	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword = repeatPassword;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public long getVerificationCode() {
		return verificationCode;
	}
	public void setVerificationCode(long verificationCode) {
		this.verificationCode = verificationCode;
	}
	public Person() {
		super();}
	public Person(String firstName, String lastName, String emailId, String password, String repeatPassword,
			String date) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.password = password;
		this.repeatPassword = repeatPassword;
		this.date = date;
	}
	public Person(String firstName, String lastName, String password, String repeatPassword, String date) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.repeatPassword = repeatPassword;
		this.date = date;
	}
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName + ", emailId=" + emailId + ", password="
				+ password + ", repeatPassword=" + repeatPassword + ", date=" + date + "]";
	}
	
	
}
