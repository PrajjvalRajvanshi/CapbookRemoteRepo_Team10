package com.cg.capbook.services;

import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.beans.Posts;

public interface CapBookServices {
public String acceptPersonDetails(Persons persons);
public Persons getPersonDetails(String emailId) throws Exception;
public boolean checkPassword(String plainPassword,String hashedPassword);
public Persons setPassword(Persons persons);
public Persons saveImage(MultipartFile photo,String personEmailId) throws Exception;
}
