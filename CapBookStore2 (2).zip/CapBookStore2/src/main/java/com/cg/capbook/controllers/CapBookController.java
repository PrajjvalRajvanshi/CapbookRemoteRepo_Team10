package com.cg.capbook.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.beans.Posts;
import com.cg.capbook.exceptions.FriendRequestAlreadySentException;
import com.cg.capbook.exceptions.PersonAccountNotFoundException;
import com.cg.capbook.services.CapBookServices;
import com.cg.capbook.services.FriendRequestServices;
import com.cg.capbook.services.PostServices;
@SessionAttributes("persons")
@Controller
public class CapBookController {
	@Autowired
	private CapBookServices capBookServices;
	@Autowired
	private PostServices postServices;
	@Autowired
	private FriendRequestServices friendRequestServices;
	 Persons persons;
	 Posts post;
	@RequestMapping("/registrationDa")
	public ModelAndView registerPersonAction(
			@Valid @ModelAttribute Persons persons,BindingResult bindingResultPersons )  {
		  if(bindingResultPersons.hasErrors()) return new ModelAndView("registerationPage");
		capBookServices.acceptPersonDetails(persons);
		return new ModelAndView("index","persons",persons);
	}
	
	@RequestMapping(value = "/logout")
	public String logoutFromApp(HttpSession session) {
		session.invalidate();
		return "index";
	}
@PostMapping("/uploadImagePage")
	public ModelAndView uploadImagePage(@RequestParam("photo") MultipartFile photo,@SessionAttribute("persons") Persons persons) throws Exception  {
		  capBookServices.getPersonDetails(persons.getPersonEmailId());
		  capBookServices.saveImage(photo,persons.getPersonEmailId());
		return new ModelAndView("profilePage","persons",persons);
	}
	

	@RequestMapping("/passwordReset")
	public ModelAndView passwordResetGeneratedCode(@RequestParam("personEmailId") String personEmailId,@RequestParam("securityAnswer") String securityAnswer) throws Exception  {
		Persons persons = capBookServices.getPersonDetails(personEmailId);
		if(capBookServices.checkPassword(securityAnswer, persons.getSecurityAnswer())==true)
		return new ModelAndView("newPassword","persons",persons);
		
		else
			return new ModelAndView("registrationSuccess","persons",persons);
	}
	
	@RequestMapping("/setPassword")
	public ModelAndView passwordSetGeneratedCode(@RequestParam("personEmailId") String personEmailId,@RequestParam("personPassword") String personPassword,@RequestParam("repeatPersonPassword") String repeatPersonPassword) throws Exception  {
		Persons persons=capBookServices.getPersonDetails(personEmailId);
		if(repeatPersonPassword.equals(personPassword)) {
			persons.setPersonPassword(personPassword);
			persons.setRepeatPersonPassword(repeatPersonPassword);
		persons=capBookServices.setPassword(persons);
		return new ModelAndView("index","persons",persons);
		}
		else
			return new ModelAndView("newPassword","persons",persons);
	}
	
	@RequestMapping("/postUpdate")
	public ModelAndView postUpdate(@RequestParam String postText,@RequestParam("personEmailId") String personEmailId) {
		try {
			persons=postServices.createPost(personEmailId, postText);
		} catch (PersonAccountNotFoundException e) {
			e.printStackTrace();
		}
		return new ModelAndView("profilePage","persons",persons);
	}
	
	@RequestMapping("/friendRequest")
	public ModelAndView sendFriendRequest(@RequestParam("senderEmailId")String senderEmailId,@RequestParam("receiverEmailId") String receiverEmailId){
		try {
			friendRequestServices.sendFriendRequest(senderEmailId, receiverEmailId);
		} catch (PersonAccountNotFoundException | FriendRequestAlreadySentException e) {
			e.printStackTrace();
		}
		try {
			persons = capBookServices.getPersonDetails(senderEmailId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("profilePage", "persons",persons);
	}
	
	@RequestMapping("/editProfile")
	public ModelAndView editProfilePage() {
		return null;
		
	}
	
}