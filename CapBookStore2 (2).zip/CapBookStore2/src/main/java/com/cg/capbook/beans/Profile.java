package com.cg.capbook.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Profile {
	private String bioInformation;
	private String profession;
	private String relationshipStatus;
	private String location;
	public Profile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Profile(String bioInformation, String profession, String relationshipStatus, String location) {
		super();
		this.bioInformation = bioInformation;
		this.profession = profession;
		this.relationshipStatus = relationshipStatus;
		this.location = location;
	}
	public String getBioInformation() {
		return bioInformation;
	}
	public void setBioInformation(String bioInformation) {
		this.bioInformation = bioInformation;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	public String getRelationshipStatus() {
		return relationshipStatus;
	}
	public void setRelationshipStatus(String relationshipStatus) {
		this.relationshipStatus = relationshipStatus;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
}
