package com.cg.capbook.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.FriendRequest;

public interface FriendRequestDaoServices extends JpaRepository<FriendRequest,Integer>{
	@Query("from FriendRequest fr where fr.senderEmailId=:senderEmailId and fr.receiverEmailId=:receiverEmailId")
public FriendRequest findFriendRequest(@Param("senderEmailId")String senderEmailId,@Param("receiverEmailId" )String receiverEmailId);

	
	  @Query("delete from FriendRequest fr where fr.senderEmailId=:senderEmailId and fr.receiverEmailId=:receiverEmailId"
	  ) public boolean deleteFriendRequest(@Param("senderEmailId")String
	  senderEmailId,@Param("receiverEmailId" )String receiverEmailId);
	 
	@Query("from FriendRequest fr where fr.receiverEmailId=:receiverEmailId")
	public List<FriendRequest> findAllPendingFriendRequest(@Param("receiverEmailId")String receiverEmailId);
}
