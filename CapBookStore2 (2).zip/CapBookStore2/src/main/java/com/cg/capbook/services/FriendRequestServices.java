package com.cg.capbook.services;

import java.util.List;

import com.cg.capbook.beans.FriendRequest;
import com.cg.capbook.exceptions.FriendRequestAlreadySentException;
import com.cg.capbook.exceptions.PersonAccountNotFoundException;

public interface FriendRequestServices  {
 public boolean sendFriendRequest(String senderEmailId, String receiverEmailId) throws PersonAccountNotFoundException, FriendRequestAlreadySentException;
 public boolean confirmFriendRequest(String senderEmailId,String receiverEmailId) throws Exception;
 public boolean declineFriendRequest(String senderEmailId, String receiverEmailId);
 public List<FriendRequest> showAllFriendRequest(String receiverEmailId);
 
}
