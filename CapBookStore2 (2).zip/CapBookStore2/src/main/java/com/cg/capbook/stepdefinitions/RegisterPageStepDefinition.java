package com.cg.capbook.stepdefinitions;

public class RegisterPageStepDefinition {

}
