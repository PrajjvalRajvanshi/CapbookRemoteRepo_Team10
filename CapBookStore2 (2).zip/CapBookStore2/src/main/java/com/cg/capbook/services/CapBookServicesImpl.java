package com.cg.capbook.services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.daoservices.CapBookDAOServices;
import com.cg.capbook.exceptions.PersonAccountNotFoundException;

@Component("capBookServices")
public class CapBookServicesImpl implements CapBookServices{
	@Autowired
	CapBookDAOServices capBookDAOServices;
	@Override
	public String acceptPersonDetails(Persons persons) {
		persons.setPersonPassword(hashPassword(persons.getPersonPassword()));
		persons.setRepeatPersonPassword(hashPassword(persons.getRepeatPersonPassword()));
		persons.setSecurityAnswer(hashPassword(persons.getSecurityAnswer()));
		persons = capBookDAOServices.save(persons);
		return persons.getPersonEmailId();
	}
	private String hashPassword(String plainTextPassword){
		return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt());
	}
	@Override
	public Persons getPersonDetails(String personEmailId) throws PersonAccountNotFoundException {
		Persons persons=capBookDAOServices.findById(personEmailId).orElseThrow(()-> new PersonAccountNotFoundException("Person Details not found for "+personEmailId));
		return persons;
	}
	@Override
	public boolean checkPassword(String plainPassword, String hashedPassword) {
		if (BCrypt.checkpw(plainPassword, hashedPassword))
			return true;
		else
			return false;
	}
	@Override
	public Persons setPassword(Persons persons) {
		persons.setPersonPassword(hashPassword(persons.getPersonPassword()));
		persons.setRepeatPersonPassword(hashPassword(persons.getRepeatPersonPassword()));
		persons=capBookDAOServices.save(persons);
		return persons;
	}
	@Override
	public Persons saveImage(MultipartFile photo,String personEmailId)throws Exception {
		Persons persons = getPersonDetails(personEmailId);
		try {
			// Get the file and save it somewhere
		byte[] bytes = photo.getBytes();
			Path path = Paths.get("D:\\JavaFullStackFinalProject\\CapBookStore2\\src\\main\\resources\\static\\images\\" + photo.getOriginalFilename());
			Files.write(path, bytes);
			//photo.transferTo(path);
			persons.setPhoto("/images/" + photo.getOriginalFilename());
			capBookDAOServices.save(persons);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return persons;
		
	}

}
