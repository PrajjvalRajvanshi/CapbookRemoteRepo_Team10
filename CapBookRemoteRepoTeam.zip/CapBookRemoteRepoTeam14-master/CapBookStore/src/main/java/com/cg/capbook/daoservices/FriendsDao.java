
 package com.cg.capbook.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Friend;
import com.cg.capbook.beans.Relationship;
 public interface FriendsDao extends JpaRepository<Friend, String>{
	 
	  @Query("from Friend where ACCOUNT_EMAIL_ID=:emailId")
			public List<Friend> showAllFriends(@Param("emailId") String emailId); 
 }
 