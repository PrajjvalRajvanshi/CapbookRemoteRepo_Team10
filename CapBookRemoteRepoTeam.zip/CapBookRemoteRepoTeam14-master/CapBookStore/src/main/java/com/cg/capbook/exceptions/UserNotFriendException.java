package com.cg.capbook.exceptions;
//abcd
public class UserNotFriendException extends Exception{

	public UserNotFriendException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserNotFriendException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public UserNotFriendException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UserNotFriendException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UserNotFriendException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
